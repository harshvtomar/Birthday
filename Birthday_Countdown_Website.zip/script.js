function login() {
    const user = document.getElementById("username").value;
    const pass = document.getElementById("password").value;
    const error = document.getElementById("error");

    if (user === "RiyaSingh" && pass === "RiyaHarsh") {
        window.location.href = "countdown.html";
    } else {
        error.textContent = "Incorrect username or password!";
    }
}

function toggleMenu() {
    document.getElementById("sideMenu").classList.toggle("open");
}

if (window.location.pathname.includes("countdown")) {
    const countDownDate = new Date("Sep 4, 2026 00:00:00").getTime();

    const x = setInterval(function () {
        const now = new Date().getTime();
        const distance = countDownDate - now;

        if (distance < 0) {
            document.getElementById("countdown").style.display = "none";
            const msg = document.getElementById("birthdayMessage");
            msg.classList.remove("hidden");
            msg.innerHTML = "Happy Birthday Riya! 🎉💖<br><br><img src='https://i.imgur.com/TrXnZQh.png' width='200'>";
            clearInterval(x);
            return;
        }

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        document.getElementById("countdown").innerHTML =
            days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
    }, 1000);
}